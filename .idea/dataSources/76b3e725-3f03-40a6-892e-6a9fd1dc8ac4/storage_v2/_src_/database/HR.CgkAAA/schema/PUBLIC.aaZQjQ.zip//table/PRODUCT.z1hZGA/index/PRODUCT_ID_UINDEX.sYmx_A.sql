create unique index PRODUCT_ID_UINDEX
    on PRODUCT (ID);

